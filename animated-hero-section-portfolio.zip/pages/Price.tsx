import React from 'react';

const Price: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto text-center py-16">
      <h1 className="text-5xl font-extrabold text-gray-900">Pricing</h1>
      <p className="mt-4 text-lg text-gray-600">Content for the price page is coming soon.</p>
    </div>
  );
};

export default Price;
