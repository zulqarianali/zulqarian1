import React from 'react';
import Hero from './components/Hero';
import WhatsAppButton from './components/WhatsAppButton';
import About from './pages/About';
import Contact from './pages/Contact';
import Portfolio from './pages/Portfolio';
import Price from './pages/Price';
import Services from './pages/Services';

const App: React.FC = () => {
  const renderPage = () => {
    const pathname = window.location.pathname;
    // Simple router to render the component based on the URL path
    switch (pathname) {
      case '/about.html':
        return <About />;
      case '/portfolio.html':
        return <Portfolio />;
      case '/contact.html':
        return <Contact />;
      case '/price.html':
        return <Price />;
      case '/services.html':
        return <Services />;
      case '/':
      case '/index.html':
      default:
        return <Hero />;
    }
  };

  const navLinks = [
    { href: "/index.html", label: "Home" },
    { href: "/contact.html", label: "Contact" },
    { href: "/about.html", label: "About" },
    { href: "/portfolio.html", label: "Portfolio" },
    { href: "/price.html", label: "Price" },
    { href: "/services.html", label: "Services" },
  ];

  return (
    <div className="min-h-screen font-sans">
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <a href="/index.html" className="text-2xl font-bold text-gray-900">ZA</a>
            </div>
            <div className="hidden md:flex items-center">
              <div className="ml-10 flex items-baseline space-x-4">
                {navLinks.map(link => (
                  <a
                    key={link.href}
                    href={link.href}
                    className="text-gray-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            </div>
            <div className="flex items-center">
               <a href="/contact.html" className="ml-4 inline-flex items-center justify-center px-5 py-2 font-medium rounded-full text-white bg-indigo-600 hover:bg-indigo-700 shadow-lg hover:shadow-indigo-500/40 transform hover:-translate-y-0.5 transition-all duration-300 text-sm">
                  Sign Up
                </a>
            </div>
          </div>
        </nav>
      </header>
      <main className="px-4 py-12 sm:px-6 lg:px-8 lg:py-20">
        {renderPage()}
      </main>
      <WhatsAppButton />
    </div>
  );
};

export default App;
