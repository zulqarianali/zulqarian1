import React, { useState, useEffect } from 'react';
import Badge from './Badge';
import StatItem from './StatItem';
import { VideoEditingIcon } from './icons/VideoEditingIcon';
import { GraphicDesignIcon } from './icons/GraphicDesignIcon';
import { SocialMediaIcon } from './icons/SocialMediaIcon';

const Hero: React.FC = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    // Trigger animations after the component mounts
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const getTransitionClass = (delay: number) => 
    `transition-all duration-700 ease-out ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`;

  return (
    <section id="hero" className="max-w-7xl mx-auto">
      <div className="bg-white rounded-3xl shadow-2xl shadow-sky-200/50 overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2">
          
          {/* Left Column: Image and Badges */}
          <div className="relative min-h-[400px] lg:min-h-full lg:order-first">
            <div className="absolute inset-0 bg-gradient-to-br from-sky-200 via-sky-100 to-white"></div>
            <div 
              className={`absolute inset-0 flex items-center justify-center p-4 transition-opacity duration-1000 ease-out ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
            >
              <div 
                className={`relative w-full h-full max-w-md transition-transform duration-1000 ease-out ${isLoaded ? 'translate-x-0' : '-translate-x-full'}`}
                style={{ transitionDelay: '200ms' }}
              >
                 {/* 
                  IMPORTANT: Replace this image src with your own image URL.
                  For best results, use a high-quality PNG with a transparent background.
                 */}
                 <img
                  className="w-full h-full object-contain drop-shadow-2xl"
                  src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEix9BtGrgUSoZSZZ0GQ3HIy_Np77YVQf5gxKgjOWPj0glsUyna1mTOImjhMYqyPKsBn-d5jUT8tJ5pVWUoFkBNEgTEt6qpyU9UmC9vYs9ML8mAbZrbAaJuXjGMj7cXXf-b8KbRjaqN51wtH0ekmaT_km8iHBFX1sSB3QgYyxkwQmAiFmUB22sNXjbck/s320/bg.png"
                  alt="Portrait of Zulqarnain Ali"
                />
                
                {/* Floating Badges */}
                <Badge 
                  text="Video Editing" 
                  icon={<VideoEditingIcon />}
                  className="absolute top-[10%] right-[-2rem] sm:right-0 animate-float-1" 
                  style={{ animationDelay: '0.2s' }} 
                />
                <Badge 
                  text="Graphic Design" 
                  icon={<GraphicDesignIcon />}
                  className="absolute top-[45%] left-[-3rem] sm:left-[-1rem] animate-float-2" 
                  style={{ animationDelay: '0.7s' }} 
                />
                <Badge 
                  text="All Social Media Services" 
                  icon={<SocialMediaIcon />}
                  className="absolute bottom-[15%] right-[-1rem] sm:right-4 animate-float-3" 
                  style={{ animationDelay: '1.2s' }} 
                />
              </div>
            </div>
          </div>

          {/* Right Column: Text Content */}
          <div className="p-8 md:p-12 lg:p-16 flex flex-col justify-center lg:order-last">
            <div style={{ transitionDelay: `${300}ms` }} className={getTransitionClass(300)}>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 tracking-tight leading-tight">
                Zulqarnain Ali — <br className="hidden sm:block" /><span className="text-indigo-600">Video Editor</span> & Graphic Designer
              </h1>
            </div>
            <div style={{ transitionDelay: `${500}ms` }} className={getTransitionClass(500)}>
              <p className="mt-6 text-lg text-gray-600 max-w-lg">
                Specializing in video editing and graphic design, I bring your vision to life with stunning visuals and compelling storytelling.
              </p>
            </div>
            <div style={{ transitionDelay: `${700}ms` }} className={getTransitionClass(700)}>
              <div className="mt-8 flex flex-wrap gap-4">
                <a href="/contact.html" className="inline-flex items-center justify-center px-8 py-3 font-medium rounded-full text-white bg-indigo-600 hover:bg-indigo-700 shadow-lg hover:shadow-indigo-500/40 transform hover:-translate-y-0.5 transition-all duration-300">
                  Get in Touch
                </a>
                <a href="/portfolio.html" className="inline-flex items-center justify-center px-8 py-3 font-medium rounded-full text-gray-700 bg-white ring-1 ring-gray-300 hover:bg-gray-50 shadow-md transform hover:-translate-y-0.5 transition-all duration-300">
                  View My Work
                </a>
              </div>
            </div>
            <div style={{ transitionDelay: `${900}ms` }} className={`mt-12 pt-8 border-t border-gray-200 w-full ${getTransitionClass(900)}`}>
              <div className="grid grid-cols-3 gap-4 text-center">
                <StatItem endValue={15} suffix="+" label="years experience" />
                <StatItem endValue={26} suffix="K" label="projects success" />
                <StatItem endValue={98} suffix="%" label="satisfied rate" />
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;
