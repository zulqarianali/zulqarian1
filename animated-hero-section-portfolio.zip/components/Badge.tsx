import React from 'react';

interface BadgeProps {
  text: string;
  icon?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

const Badge: React.FC<BadgeProps> = ({ text, icon, className = '', style }) => {
  return (
    <div 
      className={`z-20 flex items-center gap-2.5 pl-3 pr-4 py-2 bg-white/70 backdrop-blur-md rounded-full shadow-lg text-sm sm:text-base font-medium text-gray-800 hover:shadow-xl hover:scale-105 transition-all duration-300 ${className}`}
      style={style}
      role="status"
      aria-label={text}
    >
      {icon && <span className="flex-shrink-0">{icon}</span>}
      <span>{text}</span>
    </div>
  );
};

export default Badge;
