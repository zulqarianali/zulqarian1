import React, { useState, useEffect, useRef } from 'react';

interface StatItemProps {
  endValue: number;
  suffix: string;
  label: string;
  duration?: number;
}

const StatItem: React.FC<StatItemProps> = ({ endValue, suffix, label, duration = 2000 }) => {
  const [count, setCount] = useState(0);
  const hasAnimated = useRef(false);

  useEffect(() => {
    // Prevent re-animating on re-renders
    if (hasAnimated.current) return;
    hasAnimated.current = true;

    let start = 0;
    const startTime = Date.now();

    const animate = () => {
      const currentTime = Date.now();
      const progress = Math.min((currentTime - startTime) / duration, 1);
      
      // Ease-out function for a smoother animation
      const easedProgress = 1 - Math.pow(1 - progress, 4);
      
      const currentCount = Math.floor(easedProgress * endValue);
      setCount(currentCount);

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setCount(endValue);
      }
    };
    
    // Start the animation
    const animationFrameId = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrameId);
  }, [endValue, duration]);

  return (
    <div>
      <p className="text-4xl font-bold text-indigo-600 tracking-tighter">
        {count}{suffix}
      </p>
      <p className="text-sm text-gray-500 mt-1 capitalize">{label}</p>
    </div>
  );
};

export default StatItem;