import React from 'react';

export const IllustrationIcon: React.FC = () => (
  <div className="w-8 h-8 rounded-full bg-cyan-100 flex items-center justify-center ring-2 ring-white">
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-cyan-600 -rotate-12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
    </svg>
  </div>
);
